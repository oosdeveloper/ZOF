<?php
/*
Plugin Name: ZOF Calorie Calculator
Description: A simple calorie calculator tool with a pop-up result.
Version: 1.0
Author: <a href="https://zof.ae" target="_blank">zof.ae</a>
*/

function add_author_link_to_plugin_meta($plugin_meta, $plugin_file, $plugin_data, $status) {
    if (strpos($plugin_file, 'calorie-calculator.php') !== false) {
        $author_url = 'https://zof.ae'; 
        $author_link = '<a href="' . esc_url($author_url) . '" target="_blank">ZOF TECHNOLOGY</a>';
        $plugin_meta['author_link'] = $author_link;
    }
    return $plugin_meta;
}
add_filter('plugin_row_meta', 'add_author_link_to_plugin_meta', 10, 4);

function enqueue_plugin_assets() {
    // Enqueue CSS
    wp_enqueue_style('plugin-style', plugin_dir_url(__FILE__) . 'css/style.css', array(), '1.0.0', 'all');

    // Enqueue JavaScript
    wp_enqueue_script('plugin-script', plugin_dir_url(__FILE__) . 'js/script.js', array('jquery'), '1.0.0', true);
}
add_action('wp_enqueue_scripts', 'enqueue_plugin_assets');

// Add the calorie calculator form
function calorie_calculator_form() {
    ob_start(); ?>
    
    <div class="calorie-calculator-container">
        <!-- Add a title here -->
        <h2>Calorie Calculator</h2>
        <form id="calorie-calculator-form">
            <!-- Age -->
            <label for="age">Age:</label>
            <input type="number" name="age" id="age" required>

            <!-- Gender -->
            <label for="gender">Gender:</label>
            <select name="gender" id="gender" required>
                <option value="male">Male</option>
                <option value="female">Female</option>
            </select>

            <!-- Weight -->
            <label for="weight">Weight (<?php echo get_user_weight_measure(); ?>):</label>
            <input type="number" name="weight" id="weight" required>

            <!-- Height -->
            <label for="height">Height (<?php echo get_user_height_measure(); ?>):</label>
            <input type="number" name="height" id="height" required>

            <!-- Activity Level -->
            <label for="activity-level">Activity Level:</label>
            <select name="activity-level" id="activity-level" required>
                <option value="sedentary">Sedentary (little or no exercise)</option>
                <option value="lightly-active">Lightly Active (light exercise or sports 1-3 days/week)</option>
                <option value="moderately-active">Moderately Active (moderate exercise or sports 3-5 days/week)</option>
                <option value="very-active">Very Active (hard exercise or sports 6-7 days/week)</option>
                <option value="super-active">Super Active (very hard exercise, physical job, or training)</option>
            </select>

            <!-- Goals -->
            <label for="goals">Goals:</label>
            <select name="goals" id="goals" required>
                <option value="maintain">Maintain Weight</option>
                <option value="lose">Lose Weight</option>
                <option value="gain">Gain Weight</option>
            </select>

            <input type="submit" value="Calculate">
            <p class="powered-by">Powered by <a href="https://zof.ae" target="_blank">ZOF.AE</a></p>

        </form>
    </div>

    <!-- Result Pop-up -->
    <div class="overlay" id="overlay"></div>
    <div class="popup" id="result-popup">
        <div class="popup-content">
            <!-- Add an icon based on gender -->
            <div class="icon" id="gender-icon"></div>
            <!-- Bold the number in the result -->
            <p class="calorie-result" id="calorie-result"></p>
            <p id="calorie-description"></p>
            <button class="close-button" id="close-popup">Close</button>
        </div>
    </div>


    <?php
    return ob_get_clean();
}

// Create a shortcode to display the calculator
add_shortcode('calorie_calculator', 'calorie_calculator_form');

// Define default options
function calorie_calculator_default_options() {
    return array(
        'weight_measure' => 'kg', // Default measure is kilograms
        'height_measure' => 'cm', // Default measure is centimeters
    );
}

// Register options and set default values
function register_calorie_calculator_settings() {
    register_setting('calorie_calculator_options', 'calorie_calculator_settings', 'calorie_calculator_validate_settings');
    add_option('calorie_calculator_settings', calorie_calculator_default_options());
}

// Validation callback (optional)
function calorie_calculator_validate_settings($input) {
    // Add validation logic here if needed
    return $input;
}

add_action('admin_init', 'register_calorie_calculator_settings');

// Create the admin menu item and settings page
function calorie_calculator_menu() {
    add_submenu_page('tools.php', 'Calorie Calculator Settings', 'Calorie Calculator', 'manage_options', 'calorie_calculator_settings', 'calorie_calculator_settings_page');
}

add_action('admin_menu', 'calorie_calculator_menu');

// Create the settings page content
function calorie_calculator_settings_page() {
    ?>
    <div class="wrap">
        <h2>Calorie Calculator Settings</h2>
        <form method="post" action="options.php">
            <?php settings_fields('calorie_calculator_options'); ?>
            <?php $options = get_option('calorie_calculator_settings'); ?>

            <label for="weight_measure">Choose Weight Measure:</label>
            <select name="calorie_calculator_settings[weight_measure]" id="weight_measure">
                <option value="kg" <?php selected('kg', $options['weight_measure']); ?>>Kilograms (KG)</option>
                <option value="lb" <?php selected('lb', $options['weight_measure']); ?>>Pounds (LB)</option>
            </select>

            <label for="height_measure">Choose Height Measure:</label>
            <select name="calorie_calculator_settings[height_measure]" id="height_measure">
                <option value="cm" <?php selected('cm', $options['height_measure']); ?>>Centimeters (CM)</option>
                <option value="ft" <?php selected('ft', $options['height_measure']); ?>>Feet (FT)</option>
            </select>

            <p class="submit">
                <input type="submit" class="button-primary" value="Save Changes">
            </p>
        </form>
    </div>
    <?php
}

// Get the user's chosen weight measure (KG or LB)
function get_user_weight_measure() {
    $options = get_option('calorie_calculator_settings');
    return $options['weight_measure'];
}

// Get the user's chosen height measure (CM or FT)
function get_user_height_measure() {
    $options = get_option('calorie_calculator_settings');
    return $options['height_measure'];
}
?>