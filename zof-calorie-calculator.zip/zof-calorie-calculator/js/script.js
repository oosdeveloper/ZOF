document.addEventListener('DOMContentLoaded', function() {
    const form = document.getElementById('calorie-calculator-form');
    const overlay = document.getElementById('overlay');
    const resultPopup = document.getElementById('result-popup');
    const calorieResult = document.getElementById('calorie-result');
    const calorieDescription = document.getElementById('calorie-description');
    const closePopup = document.getElementById('close-popup');
    const genderIcon = document.getElementById('gender-icon');

    form.addEventListener('submit', function(event) {
        event.preventDefault();

        // Retrieve user inputs
        const age = parseFloat(document.getElementById('age').value);
        const gender = document.getElementById('gender').value;
        const weight = parseFloat(document.getElementById('weight').value);
        const height = parseFloat(document.getElementById('height').value);
        const activityLevel = document.getElementById('activity-level').value;
        const goals = document.getElementById('goals').value;

        // Display "Calculating..." message
        calorieResult.innerHTML = "Calculating...";
        calorieDescription.innerHTML = "";
        resultPopup.style.display = 'block';
        overlay.style.display = 'block';

        // Calculate daily calories (replace with your logic)
        const calories = calculate_daily_calories(age, gender, weight, height, activityLevel, goals);

        // Display the result in the pop-up
        calorieResult.innerHTML = `Your daily calorie target is: <span class="${goals}-color">${calories}</span> calories.`;

        // Provide a description based on goals
        if (goals === 'maintain') {
            calorieDescription.innerHTML = "This is the number of calories you need to maintain your current weight.";
        } else if (goals === 'lose') {
            calorieDescription.innerHTML = "This is the number of calories you need to lose weight. To lose 1 pound per week, aim for a calorie deficit of 500 calories per day.";
        } else if (goals === 'gain') {
            calorieDescription.innerHTML = "This is the number of calories you need to gain weight. To gain 1 pound per week, aim for a calorie surplus of 500 calories per day.";
        }

        // Add icon based on gender
        if (gender === 'male') {
            genderIcon.innerHTML = '♂️'; // Man icon
        } else {
            genderIcon.innerHTML = '♀️'; // Woman icon
        }
    });

    // Close the pop-up when the "Close" button is clicked
    closePopup.addEventListener('click', function() {
        resultPopup.style.display = 'none';
        overlay.style.display = 'none';
    });

    // Function to calculate daily calories
    function calculate_daily_calories(age, gender, weight, height, activityLevel, goals) {
        // Replace this with your actual calorie calculation logic
        // Example calculation: (dummy formula)
        let calories = 0;

        if (gender === 'male') {
            calories = (10 * weight) + (6.25 * height) - (5 * age) + 5;
        } else {
            calories = (10 * weight) + (6.25 * height) - (5 * age) - 161;
        }

        // Adjust for activity level
        switch (activityLevel) {
            case 'sedentary':
                calories *= 1.2;
                break;
            case 'lightly-active':
                calories *= 1.375;
                break;
            case 'moderately-active':
                calories *= 1.55;
                break;
            case 'very-active':
                calories *= 1.725;
                break;
            case 'super-active':
                calories *= 1.9;
                break;
        }

        // Adjust for goals
        if (goals === 'lose') {
            calories -= 500;
        } else if (goals === 'gain') {
            calories += 500;
        }

        return calories.toFixed(2); // Return calories rounded to two decimal places
    }
});