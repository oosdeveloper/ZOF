# Calorie Calculator Plugin

## Description

The Calorie Calculator Plugin is a simple and user-friendly tool that allows users to calculate their daily calorie targets based on their age, gender, weight, height, activity level, and fitness goals. It provides valuable insights for individuals looking to maintain, lose, or gain weight.


Key features:

- Accurate calorie calculation based on user input.
- Customizable weight and height measures (KG/LB and CM/FT).
- Results presented in an attractive and easy-to-understand pop-up window.
- Integration with the ZOF Company's branding and hyperlink to their website.

## Installation

1. Download the `zof-calorie-calculator.zip` file from the [GitHub repository](https://github.com/oosdeveloper/ZOF-Calorie-Calculator).
2. Log in to your WordPress admin panel.
3. Navigate to Plugins > Add New.
4. Click the Upload Plugin button.
5. Choose the `zof-calorie-calculator.zip` file and click Install Now.
6. Once installed, activate the plugin.

## Usage

To add the Calorie Calculator to your website, you can use the `[calorie_calculator]` shortcode. Place this shortcode on any page or post where you want the calculator to appear.

Example:

[calorie_calculator]

The calculator will be displayed on the page, and users can enter their information to get their daily calorie target.

## Configuration

### Weight and Height Measures

You can configure the weight and height measures (KG/LB and CM/FT) in the plugin settings. To do this:

1. Go to Tools > Calorie Calculator Settings in your WordPress admin panel.
2. Choose your preferred weight and height measures.
3. Click the Save Changes button.

### Customization

You can customize the plugin's appearance by modifying the CSS styles in the `style.css` file located in the plugin's folder.

## Support and Feedback

If you encounter any issues or have feedback or feature requests, please [submit an issue on GitHub](https://github.com/oosdeveloper/ZOF-Calorie-Calculator/issues).

For general inquiries and support, visit our website [https://zof.ae or contact us at support@zof.ae.]

## License

This plugin is licensed under the MIT License. See the (LICENSE) file for details.

---

© ZOF TECHNOLOGY (https://zof.ae)
