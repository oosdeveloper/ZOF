== Calorie Calculator Plugin ==

Contributors: ZOF TECHNOLOGY
Tags: calorie calculator, health, fitness, nutrition
Tested up to: 6.3.1
Stable tag: 1.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

== Description ==

The Calorie Calculator Plugin is a simple and effective tool for calculating your daily calorie needs. It helps you determine the number of calories you should consume to maintain, lose, or gain weight based on your age, gender, weight, height, activity level, and goals.

== Features ==

- Calculate daily calorie targets for maintaining, losing, or gaining weight.
- Customizable weight and height measures (e.g., kg/lb, cm/ft).
- Provides a pop-up result with a detailed calorie target.
- Easy-to-use form integrated into your WordPress site.
- Supports both metric and imperial measurements.

== Installation ==

1. Upload the "calorie-calculator" folder to the "/wp-content/plugins/" directory.
2. Activate the plugin through the "Plugins" menu in WordPress.
3. Use the `[calorie_calculator]` shortcode to add the calculator to your pages or posts.

== Usage ==

1. Create or edit a page or post where you want to display the calorie calculator.
2. Add the `[calorie_calculator]` shortcode to the content.
3. Save or update the page/post.
4. Visitors to your site can now use the calorie calculator to determine their daily calorie targets.

== Frequently Asked Questions ==

= Can I customize the weight and height measures? =

Yes, you can customize the weight and height measures (e.g., kg/lb, cm/ft) from the plugin settings.

= How do I change the weight and height measures? =

Go to the "Calorie Calculator Settings" page in your WordPress dashboard, where you can choose your preferred weight and height measures.

= Is this plugin free to use? =

Yes, the Calorie Calculator Plugin is free to use and is released under the GPL-2.0 license.


== Changelog ==

= 1.0 =
* Initial release of the Calorie Calculator Plugin.

== Upgrade Notice ==

= 1.0 =
Initial release.

== License ==

This plugin is licensed under the GNU General Public License v2 or later:

- License: GPLv2 or later
- License URI: https://www.gnu.org/licenses/gpl-2.0.html
